import 'package:polymer/builder.dart';
        
main(args) {
  build(entryPoints: ['web/poly01.html'],
        options: parseOptions(args));
}
